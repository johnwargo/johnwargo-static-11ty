package com.johnwargo.contactlookup;

import net.rim.device.api.ui.UiApplication;

public class ContactLookup extends UiApplication {

	public static void main(String[] args) {
		ContactLookup theApp = new ContactLookup();
		theApp.enterEventDispatcher();
	}

	public ContactLookup() {
		pushScreen(new ContactLookupScreen(this));
	}
}

