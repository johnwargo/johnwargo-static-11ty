package com.johnwargo.contactlookup;

import java.util.Vector;
import net.rim.device.api.system.Characters;
import net.rim.device.api.system.Display;
import net.rim.device.api.ui.DrawStyle;
import net.rim.device.api.ui.Graphics;
import net.rim.device.api.ui.MenuItem;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.ListField;
import net.rim.device.api.ui.component.ListFieldCallback;
import net.rim.device.api.ui.component.Menu;
import net.rim.device.api.ui.component.SeparatorField;
import net.rim.device.api.ui.component.Status;
import net.rim.device.api.ui.container.MainScreen;

import com.johnwargo.domdirlookup.DomDirLookup_Stub;
import com.johnwargo.domdirlookup.USERINFO;

final class ContactLookupScreen extends MainScreen {

	private static String promptString = "Please enter the last three characters of the contact's last name and press the menu button to continue.";
	private EditField editSearch;
	private ListField editList;
	private ListCallback myCallback;
	private DomDirLookup_Stub stub;
	private ContactLookup app;

	public ContactLookupScreen(ContactLookup app) {
		super(DEFAULT_MENU | DEFAULT_CLOSE);
		// Get a copy of the current application object so we can use it
		// to open the details screen
		this.app = app;
		// Set the title for the application window
		setTitle(new LabelField("Contact Lookup", LabelField.ELLIPSIS
				| LabelField.USE_ALL_WIDTH));
		// Add the label to the screen
		add(new LabelField(promptString));
		// Create a edit box to take the search screen
		editSearch = new EditField(EditField.FILTER_DEFAULT);
		// Add the search field to the screen
		add(editSearch);
		// Add a separator to delineate between the search string
		// and the list of contacts
		add(new SeparatorField());
		// Create a ListField to contain the search results
		editList = new ListField();
		myCallback = new ListCallback();
		editList.setCallback(myCallback);
		editList.setEmptyString("", DrawStyle.HCENTER);
		// Add the ListField to the screen
		add(editList);
	}

	public void makeMenu(Menu menu, int instance) {
		// Add the menu items to the menu when the user presses the button
		menu.add(mnuAbout);
		menu.add(mnuClose);
		// Only add the GetContcts when the edit field contains a value
		if (this.getLeafFieldWithFocus() == editSearch) {
			if (editSearch.getText().length() > 0) {
				menu.add(mnuGetContacts);
			}
		}
		// Add the Get Contact Details menu option of a name is selected
		if (!editList.isEmpty()) {
			// Does the user list have focus?
			if (this.getLeafFieldWithFocus() == editList) {
				// Then add the menu item
				menu.add(mnuGetContact);
			}
		}
	}

	public MenuItem mnuGetContacts = new MenuItem("Get Contact List", 100, 1) {
		public void run() {
			int i; // Loop counter
			String[] userList; // string array holds the list of contacts

			// Just in case there are previous results, erase the list of items
			if (editList.getSize() > 0) {
				editList.setSize(0);
				myCallback.erase();
			}

			try {
				// If we haven't created a stub instance, create one
				if (stub == null) {
					stub = new DomDirLookup_Stub();
				}
				// Call the GetUserList function
				userList = stub.GETUSERLIST(editSearch.getText());
				// did we get any contacts back?
				if (userList.length > 0) {
					// For some reason the web service returns one extra entry,
					// so we'll just skip the first entry in the array.
					for (i = 0; i < userList.length; i++) {
						// Make room in the list box for the element
						editList.insert(i);
						// Then add the contact name to the list
						myCallback.insert(userList[i].toString(), i);
					}
					// Select the first item in the list
					editList.setSelectedIndex(0);
				} else {
					// Tell the user when there are no results
					Status.show("No contacts found.");
				}
			} catch (Exception ex) {
				Dialog
						.alert("Unable to connect to service. Service returned:\n"
								+ ex.toString());
			}
		}
	};

	public MenuItem mnuGetContact = new MenuItem("Get Contact Details", 200, 2) {
		public void run() {

			USERINFO userInfo; // holds the contact details

			// Just in case, make sure we have a selected item
			if (editList.getSelectedIndex() > -1) {
				try {
					// Call the web service, get the contact details
					userInfo = stub.GETUSERDETAILS(myCallback.get(editList,
							editList.getSelectedIndex()).toString());
					app.pushScreen(new ContactDetailsScreen(userInfo));
				} catch (Exception ex) {
					Dialog
							.alert("Unable to connect to service. Service returned:\n"
									+ ex.toString());
				}
			}
		}
	};

	public MenuItem mnuAbout = new MenuItem("About", 200000, 9) {
		public void run() {
			Status.show("Created by:\nJohn M. Wargo\nBoxTone, Inc.");
		}
	};

	public MenuItem mnuClose = new MenuItem("Close", 200000, 10) {
		public void run() {
			// Mark the form as NOT dirty so it doesn't prompt to save
			setDirty(false);
			// Leave the program
			System.exit(0);
		}
	};

	protected boolean keyChar(char c, int status, int time) {
		// Override keyChar to make sure Escape doesn't prompt to save changes.
		if (c == Characters.ESCAPE) {
			this.setDirty(false);
		}
		return super.keyChar(c, status, time);
	}

	public static class ListCallback implements ListFieldCallback {

		private Vector listElements = new Vector();

		public void drawListRow(ListField list, Graphics g, int index, int y,
				int w) {
			String text = (String) listElements.elementAt(index);
			g.drawText(text, 0, y, 0, w);
		}

		public Object get(ListField list, int index) {
			return listElements.elementAt(index);
		}

		public int indexOfList(ListField list, String p, int s) {
			return listElements.indexOf(p, s);
		}

		public int getPreferredWidth(ListField list) {
			return Display.getWidth();
		}

		public void insert(String toInsert, int index) {
			listElements.addElement(toInsert);
		}

		public void erase() {
			listElements.removeAllElements();
			listElements.setSize(0);
		}

	}; // ListCallBack

}