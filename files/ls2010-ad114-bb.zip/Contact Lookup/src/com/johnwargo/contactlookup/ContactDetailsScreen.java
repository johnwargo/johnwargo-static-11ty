package com.johnwargo.contactlookup;

import net.rim.device.api.system.Characters;
import net.rim.device.api.ui.component.ActiveRichTextField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.container.*;

import com.johnwargo.domdirlookup.USERINFO;

final class ContactDetailsScreen extends MainScreen {

	public ContactDetailsScreen( USERINFO contactInfo ) {
		super(DEFAULT_MENU | DEFAULT_CLOSE);
		setTitle(new LabelField("Contact Details", LabelField.ELLIPSIS
				| LabelField.USE_ALL_WIDTH));
		add(new LabelField("Full Name:"));
		addActiveField(contactInfo.getFULLNAME().toString());
		add(new LabelField("Office Phone:"));
		addActiveField(contactInfo.getOFFICEPHONE().toString());
		add(new LabelField("Mobile Phone:"));
		addActiveField(contactInfo.getMOBILEPHONE().toString());
		add(new LabelField("Email Address:"));
		addActiveField(contactInfo.getEMAILADDRESS().toString());
	}

	public void addActiveField(String strValue) {
		//Create a temporary field
		ActiveRichTextField tmpField;
		//Create the field
		tmpField = new ActiveRichTextField(strValue);
		//Make it read only
		tmpField.setEditable(false);
		//Add the field to the screen
		add(tmpField);
	}

	protected boolean keyChar(char c, int status, int time) {
		// Override keyChar to make sure Escape doesn't prompt to save changes.
		if (c == Characters.ESCAPE) {
			this.setDirty(false);
		}
		return super.keyChar(c, status, time);
	}
	
}
