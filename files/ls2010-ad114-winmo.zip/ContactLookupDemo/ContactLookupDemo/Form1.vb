﻿Public Class Form1

    
    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        'Objects/variables
        Dim contactList As String()
        Dim i As Integer
        Dim loopCounter As Integer
        'The web service we're going to be calling
        Dim ws As New domDirLookup.DomDirLookupService

        'Clear out any previous results in case we have them
        Me.ListBox1.Items.Clear()

        'Do we have anything in the search box?
        If (Me.TextBox1.Text.Length > 0) Then
            Cursor.Current = Cursors.WaitCursor
            'Call the web service and get the list of contacts
            contactList = ws.GETUSERLIST(Me.TextBox1.Text)
            Cursor.Current = Cursors.Default
            If (contactList.Count > 0) Then
                loopCounter = contactList.Count - 1
                'Populate the list box with the results of the service call
                For i = 0 To loopCounter
                    Me.ListBox1.Items.Add(contactList(i))
                Next i
            End If
        End If
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        'Objects/Variables
        Dim contactInfo As domDirLookup.USERINFO
        'The web service we're going to be calling
        Dim ws As New domDirLookup.DomDirLookupService

        'Do we have a selected item
        If (ListBox1.SelectedIndex > -1) Then
            Cursor.Current = Cursors.WaitCursor
            'Connect to the web service to get the contact information
            contactInfo = ws.GETUSERDETAILS(Me.ListBox1.SelectedItem.ToString)
            Cursor.Current = Cursors.Default
            'Populate the text boxes on the screen
            Me.TextBox2.Text = contactInfo.FULLNAME
            Me.TextBox3.Text = contactInfo.OFFICEPHONE
            Me.TextBox4.Text = contactInfo.MOBILEPHONE
            Me.TextBox5.Text = contactInfo.EMAILADDRESS
        End If
    End Sub
End Class
